package com.mindgate.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtAuthenticationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtAuthenticationProjectApplication.class, args);
	}

}
//https://www.geeksforgeeks.org/spring-boot-3-0-jwt-authentication-with-spring-security-using-mysql-database/
