package com.example.demo.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Dosa;
import com.example.demo.entities.Juice;
import com.example.demo.repositories.DosaRepository;
import com.example.demo.repositories.JuiceRepository;
import com.example.demo.repositories.TeaRepository;

@Service
public class FoodServiceImpl implements FoodService {

	@Autowired TeaRepository teaRepository;
	@Autowired JuiceRepository juiceRepository;
	@Autowired DosaRepository dosaRepository;
	
	@Override
	public List<Object> serveJuiceAndDosa(String juiceName,String dosaName) {
		

		Juice juiceObj = 
				juiceRepository.findAll().stream().
				filter(j->j.getJuiceType().equals(juiceName))
				.findFirst().orElse(null);
		
		Dosa dosaObj = 
				dosaRepository.findAll().stream().
				filter(j->j.getDosaType().equals(dosaName))
				.findFirst().orElse(null);
		
		List<Object> listOfObjects = new ArrayList();
		listOfObjects.add(juiceObj);
		listOfObjects.add(dosaObj);

		return listOfObjects;
	}

	@Override
	public List<Object> serveDosaAndTea() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> serveDosaAndJuice() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> serveDosaTeaAndJuice() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Object> serveTeaAndJuice() {
		// TODO Auto-generated method stub
		return null;
	}

}
