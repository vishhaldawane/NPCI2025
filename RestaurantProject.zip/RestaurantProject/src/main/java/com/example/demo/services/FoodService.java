package com.example.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface FoodService {

	//we offer variety of combination of food services
	
	List<Object> serveJuiceAndDosa(String juiceName,String dosaName);
	List<Object> serveDosaAndTea();
	List<Object> serveDosaAndJuice();
	List<Object> serveDosaTeaAndJuice();
	List<Object> serveTeaAndJuice();

	
}
