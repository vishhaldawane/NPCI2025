package com.example.demo.entities;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Component
@Entity
@Table
public class Dosa {

	@Id
	private int dosaId;
	
	@Column(length=20)
	private String dosaType;
	private float dosaPrice;
	
	
	
	
	public Dosa() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dosa(int dosaId, String dosaType, float dosaPrice) {
		super();
		this.dosaId = dosaId;
		this.dosaType = dosaType;
		this.dosaPrice = dosaPrice;
	}
	public int getDosaId() {
		return dosaId;
	}
	public void setDosaId(int dosaId) {
		this.dosaId = dosaId;
	}
	public String getDosaType() {
		return dosaType;
	}
	public void setDosaType(String dosaType) {
		this.dosaType = dosaType;
	}
	public float getDosaPrice() {
		return dosaPrice;
	}
	public void setDosaPrice(float dosaPrice) {
		this.dosaPrice = dosaPrice;
	}
	@Override
	public String toString() {
		return "Dosa [dosaId=" + dosaId + ", dosaType=" + dosaType + ", dosaPrice=" + dosaPrice + "]";
	}
	

}
