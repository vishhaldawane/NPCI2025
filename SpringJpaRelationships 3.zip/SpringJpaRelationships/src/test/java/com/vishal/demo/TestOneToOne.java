package com.vishal.demo;
import java.time.LocalDate;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.vishal.demo.one2one.Passport;
import com.vishal.demo.one2one.Person;
import com.vishal.demo.repository.PassportRepository;
import com.vishal.demo.repository.PersonRepository;

@SpringBootTest
public class TestOneToOne {
	
	@Autowired
	PersonRepository personRepo;
	
	@Autowired
	PassportRepository passportRepo;
	
	@Test
	public void testAddPersonWithoutPassport() {
		Person person = new Person();
		person.setName("Lalit");
		personRepo.save(person);
		
	}
	
	@Test
	public void testAddPassportWithoutPerson() {
		Passport passport = new Passport();
		passport.setIssuedBy("Govt.Of UK");
		passport.setIssuedDate(LocalDate.of(2024, 9, 20));
		passportRepo.save(passport);
	}

	
	
	@Test
	public void testAddPersonAlongWithPassport() {
		
			Person person = new Person();
			person.setName("Sumit");
			personRepo.save(person); //STORE IT
			
			Passport passport = new Passport();
				passport.setIssuedBy("Govt.Of Netherlands");
				passport.setIssuedDate(LocalDate.of(2023, 9, 22));		
		
				passport.setPerson(person); //set the FK value
				passportRepo.save(passport);//STORE IT
		
	}
	
	@Test
	public void assingExistingPassportToExistingPersonTest()
	{
		Person retrievedPerson = 
				personRepo.findById(1).get();
			
			Assertions.assertTrue(retrievedPerson!=null);
			System.out.println("Person id   : "+retrievedPerson.getId());
			System.out.println("Person Name : "+retrievedPerson.getName());
			System.out.println("------------");
			
			Passport retrievedPassport = 
					passportRepo.findById(1).get();
			Assertions.assertTrue(retrievedPassport!=null);
	
			System.out.println("Passport Number : "+retrievedPassport.getPassportNumber());
			System.out.println("Passport Issued : "+retrievedPassport.getIssuedBy());
			System.out.println("Passport Date   : "+retrievedPassport.getIssuedDate());
			
			retrievedPassport.setPerson(retrievedPerson);
			passportRepo.save(retrievedPassport);
		
	}
/*
 Hibernate: select p1_0.id,p1_0.name,
 					p2_0.passport_number,
 					p2_0.issued_by,
 					p2_0.issued_date from 
 					person3 p1_0 left join passport3 p2_0 
 					on p1_0.id=p2_0.person_id 
 					where p1_0.id=?
 

 */
	@Test
	public void testReadPerson()
	{
		Person retrievedPerson = 
				personRepo.findById(2).get(); //expect a select query to run to find 2
						// select * from person3 where id=2; // Sumit is found
		
		Assertions.assertTrue(retrievedPerson!=null);
		System.out.println("Person id   : "+retrievedPerson.getId());
		System.out.println("Person Name : "+retrievedPerson.getName());
		System.out.println("------------");
		
		Passport passport = retrievedPerson.getPassport();
		
		System.out.println("Passport Number : "+passport.getPassportNumber());
		System.out.println("Passport Issued : "+passport.getIssuedBy());
		System.out.println("Passport Date   : "+passport.getIssuedDate());
		System.out.println("Passport Person : "+passport.getPerson().getName());
	}
	
	@Test
	public void testReadPassport()
	{
		Passport retrievedPassport = 
				passportRepo.findById(2).get();
		
		Assertions.assertTrue(retrievedPassport!=null);

		System.out.println("Passport Number : "+retrievedPassport.getPassportNumber());
		System.out.println("Passport Issued : "+retrievedPassport.getIssuedBy());
		System.out.println("Passport Date   : "+retrievedPassport.getIssuedDate());
		
		Person person = retrievedPassport.getPerson();
				
		System.out.println("---PERSON---");
		System.out.println("Person id       : "+person.getId());
		System.out.println("Person Name     : "+person.getName());
		System.out.println("Passport Issued : "+person.getPassport().getIssuedBy());
		System.out.println("------------");
	}
	
}