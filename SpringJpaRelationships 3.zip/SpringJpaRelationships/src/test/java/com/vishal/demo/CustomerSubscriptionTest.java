package com.vishal.demo;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.vishal.demo.manytomany.Customer;
import com.vishal.demo.manytomany.Subscription;
import com.vishal.demo.repository.CustomerRepository;
import com.vishal.demo.repository.SubscriptionRepository;

@SpringBootTest
public class CustomerSubscriptionTest {

	CustomerRepository custRepo;
	SubscriptionRepository subRepo;
	
	@Autowired
	public void init(CustomerRepository custRepo, SubscriptionRepository subRepo) {
		System.out.println("init() invoked.....");
		this.custRepo = custRepo;
		this.subRepo = subRepo;
	}
	
	@Test
	public void testCase1() {
		
		Customer cust = new Customer();
		cust.setName("Jack"); cust.setEmail("jack@gmail.com");
		System.out.println("customer 1 is created...");
		
		custRepo.save(cust);
		System.out.println("customer 1 is merged...");
		
		cust = new Customer();
		cust.setName("Janet"); cust.setEmail("janet@gates.com");
		System.out.println("customer 2 is created...");
		
		custRepo.save(cust);
		System.out.println("customer 2 is merged...");
		
		Subscription subs = new Subscription();
		subs.setType("Book"); subs.setDuration(30);
		System.out.println("Subscription 1 is created...");
		
		subRepo.save(subs);
		System.out.println("Subscription 1 is merged...");
		
		
		subs = new Subscription();
		subs.setType("CD And DVD"); subs.setDuration(7);
		System.out.println("Subscription 2 is created...");
		
		subRepo.save(subs);
		System.out.println("Subscription 2 is merged...");
		
		
	}
	
	@Test
	public void testCase2() {
		Customer cust = custRepo.findById(2).get();
		Subscription sub = subRepo.findById( 2).get();
		cust.getSubscriptions().add(sub);
		custRepo.save(cust);

	}
}
