package com.vishal.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.demo.manytomany.Subscription;

public interface SubscriptionRepository extends JpaRepository<Subscription, Integer> {

}
