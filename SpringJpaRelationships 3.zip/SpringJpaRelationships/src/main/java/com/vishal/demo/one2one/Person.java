package com.vishal.demo.one2one;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;



/*
 * STD		DIV	ROLLNO
 * X		A	1
 * X		B	1
 * XI		A	1
 * XI 		B	1
 */
@Entity
@Table(name="person3") //ORM
public class Person {
	@Id
	@GeneratedValue 			//use SequenceGenerator for custom generated values 
	private Long   id; //101
	private String name;//Sakshi
	
	
	
	@OneToOne(
		mappedBy="person", 
		cascade = 
		CascadeType.ALL) //hasA
	private Passport passport;
	
	
	
	public Passport getPassport() {
		return passport;
	}
	public void setPassport(Passport passport) {
		this.passport = passport;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
/*
 * create table person
 * (
 *    number long primary key 
 
*/
