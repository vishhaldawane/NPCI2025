package com.vishal.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.demo.one2one.Passport;

public interface PassportRepository extends JpaRepository<Passport, Integer> {

}
