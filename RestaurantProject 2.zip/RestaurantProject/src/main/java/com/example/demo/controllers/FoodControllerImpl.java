package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Dosa;
import com.example.demo.entities.Juice;
import com.example.demo.entities.Tea;
import com.example.demo.services.FoodService;

@RestController
@RequestMapping("/foodie")
public class FoodControllerImpl implements FoodController {
	@Autowired  FoodService foodService;	
	
	// http://localhost:8080/foodie/add
	@PostMapping("/add")
	public void createNewDosa(@RequestBody Dosa dosa) {
		foodService.addNewDosa(dosa);
	}
	
	
	public void editExistingDosa(Dosa dosa) {}
	public void removeExistingDosa(int id) {}
	public List<Dosa> fetchAllDosas(){ return null;}
	public Dosa fetchDosaById(int id) {return null;}
	
	
	
	
	
	//  http://localhost:8080/foodie/order1/Apple/Masala
	@Override
	@GetMapping("/order1/{jt}/{dt}")
	public List<Object> acceptOrderForJuiceAndDosa(
			@PathVariable("jt") String j, 
			@PathVariable("dt") String d) {
		List<Object> list = foodService.serveJuiceAndDosa(j, d);	
		return list;
	}
	
	// http://localhost:8080/foodie/juice/Apple
	@GetMapping("/juice/{hint}")
	public Juice acceptJuiceOrder(@PathVariable String hint) {
		return foodService.getJuice(hint);
	}
	
	// http://localhost:8080/foodie/dosa/Masala

	@GetMapping("/dosa/{hint}")
	public Dosa acceptDosaOrder(@PathVariable String hint) {
		return foodService.getDosa(hint);
	}
	
	// http://localhost:8080/foodie/tea/Black Tea

	@GetMapping("/tea/{hint}")
	public Tea acceptTeaOrder(@PathVariable String hint) {
		return foodService.getTea(hint);
	}

}
