package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Dosa;

public interface DosaRepository extends JpaRepository<Dosa, Integer> {

	List<Dosa> findByDosaType(String dosaType);
	
}
