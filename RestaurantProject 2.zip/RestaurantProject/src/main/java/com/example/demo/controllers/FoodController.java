package com.example.demo.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Dosa;
import com.example.demo.entities.Juice;

@RestController
public interface FoodController {

	List<Object> acceptOrderForJuiceAndDosa(String j, String d);
	
	Juice acceptJuiceOrder(String j);
	Dosa acceptDosaOrder(String d);
	
	void createNewDosa(Dosa dosa);
	void editExistingDosa(Dosa dosa);
	void removeExistingDosa(int id);
	List<Dosa> fetchAllDosas();
	Dosa fetchDosaById(int id);
	
}
