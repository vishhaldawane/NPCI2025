package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Dosa;
import com.example.demo.entities.Tea;

public interface TeaRepository extends JpaRepository<Tea, Integer> {

	List<Tea> findByTeaType(String teaType);

}
