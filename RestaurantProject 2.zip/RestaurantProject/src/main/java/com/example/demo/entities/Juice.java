package com.example.demo.entities;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Component
@Entity
@Table
public class Juice {

	@Id
	private int juiceId;
	
	@Column(length=20)
	private String juiceType;
	private float juicePrice;
	
	
	
	
	
	@Override
	public String toString() {
		return "Juice [juiceId=" + juiceId + ", juiceType=" + juiceType + ", juicePrice=" + juicePrice + "]";
	}
	public Juice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Juice(int juiceId, String juiceType, float juicePrice) {
		super();
		this.juiceId = juiceId;
		this.juiceType = juiceType;
		this.juicePrice = juicePrice;
	}
	public int getJuiceId() {
		return juiceId;
	}
	public void setJuiceId(int juiceId) {
		this.juiceId = juiceId;
	}
	public String getJuiceType() {
		return juiceType;
	}
	public void setJuiceType(String juiceType) {
		this.juiceType = juiceType;
	}
	public float getJuicePrice() {
		return juicePrice;
	}
	public void setJuicePrice(float juicePrice) {
		this.juicePrice = juicePrice;
	}
	
	
	
}
