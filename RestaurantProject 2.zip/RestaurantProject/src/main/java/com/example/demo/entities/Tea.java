package com.example.demo.entities;

import org.springframework.stereotype.Component;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Component
@Entity
@Table
public class Tea {

	@Id
	private int teaId;
	
	@Column(length=20)
	private String teaType;
	private float teaPrice;
	
	
	
	
	@Override
	public String toString() {
		return "Tea [teaId=" + teaId + ", teaType=" + teaType + ", teaPrice=" + teaPrice + "]";
	}



	public Tea() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Tea(int teaId, String teaType, float teaPrice) {
		super();
		this.teaId = teaId;
		this.teaType = teaType;
		this.teaPrice = teaPrice;
	}



	public int getTeaId() {
		return teaId;
	}
	public void setTeaId(int teaId) {
		this.teaId = teaId;
	}
	public String getTeaType() {
		return teaType;
	}
	public void setTeaType(String teaType) {
		this.teaType = teaType;
	}
	public float getTeaPrice() {
		return teaPrice;
	}
	public void setTeaPrice(float teaPrice) {
		this.teaPrice = teaPrice;
	}
	


}
