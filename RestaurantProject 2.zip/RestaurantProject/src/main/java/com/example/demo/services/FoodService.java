package com.example.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entities.Dosa;
import com.example.demo.entities.Juice;
import com.example.demo.entities.Tea;

@Service
public interface FoodService {

	//we offer variety of combination of food services
	
	List<Object> serveJuiceAndDosa(String juiceName,String dosaName);
	List<Object> serveDosaAndTea();
	List<Object> serveDosaAndJuice();
	List<Object> serveDosaTeaAndJuice();
	List<Object> serveTeaAndJuice();
	
	Dosa getDosa(String hint) ;
	Juice getJuice(String hint) ;
	Tea getTea(String hint) ;
	
	void addNewDosa(Dosa dosa);
	void modifyExistingDosa(Dosa dosa);
	void deleteExistingDosa(int id);
	List<Dosa> getAllDosas();
	Dosa getDosaById(int id);
	
	
}
