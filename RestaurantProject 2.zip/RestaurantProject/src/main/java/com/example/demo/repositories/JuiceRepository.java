package com.example.demo.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Dosa;
import com.example.demo.entities.Juice;

public interface JuiceRepository extends JpaRepository<Juice, Integer> {

	List<Juice> findByJuiceType(String juiceType);

}
