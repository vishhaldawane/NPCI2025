package com.vishal.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vishal.demo.one2one.Person;

public interface PersonRepository extends JpaRepository<Person, Integer> {

}
