package com.vishal.demo.one2one;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;




@Entity
@Table(name="passport3")
public class Passport {	
	@Id
	@GeneratedValue
	private Long passportNumber; //123123123
	private String issuedBy;  //Govt Of India
	private LocalDate issuedDate; //2024-12-28
	
	
	@OneToOne
	@JoinColumn
	(name="person_id")
	private Person person; //invoking
	//the setter method of the
	//above field, means filling
	//up the foreign key value
		
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public Long getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(Long passportNumber) {
		this.passportNumber = passportNumber;
	}
	public String getIssuedBy() {
		return issuedBy;
	}
	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}
	public LocalDate getIssuedDate() {
		return issuedDate;
	}
	public void setIssuedDate(LocalDate issuedDate) {
		this.issuedDate = issuedDate;
	}
	
	
}